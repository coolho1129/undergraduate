//2021114818
//김찬호

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class KtxReservationApp extends JFrame {
	;
	JLabel label =new JLabel("KTX 좌석 현황");
	JLabel seat[][]=new JLabel[4][10];
	JPanel panel=new JPanel();
	JButton bt =new JButton("예약 시작");
	
	public KtxReservationApp() {
		
		setTitle("KTX 예약시스템");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		label.setFont(new Font("TimesRoman", Font.PLAIN, 30));
		label.setForeground(Color.BLACK); // 글자색 변경
		label.setHorizontalAlignment(JLabel.CENTER);
		
		bt.addActionListener(new MyButtonListener());
		
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(label,BorderLayout.NORTH);
		c.add(panel,BorderLayout.CENTER);
		panel.setLayout(new GridLayout(4,10,5,5));
		for(int i=0;i<4;i++) {
			for(int j=0;j<10;j++) {
				seat[i][j]=new JLabel("1D");
				panel.add(seat[i][j]);
			}
		}
		
	
		
		
		c.add(bt,BorderLayout.SOUTH);
		setSize(800,600); 
		setVisible(true);
		
		
	}
	
	private class  MyButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e) { 
			JButton bt =(JButton)e.getSource();
			
		
		}
	}
	
	public static void main(String[] args) {
		new KtxReservationApp();

	}

}

//2021114818
//김찬호
public class KtxSeat {
	int [][] seats =new int [4][10];
	String [][]owner=new String[4][10];
	int findcol,findrow,Seat=0;
	

	
	
	public int reserveSeat(String seatName) {
		
		if(seatName.length()==2) {
		  findcol=seatName.charAt(0)-'0'-1;
		  findrow=seats.length-1-(seatName.charAt(1)-'A');
		}
			
		else if(seatName.length()==3) {
			findcol=(seatName.charAt(0)-'0')*10+seatName.charAt(1)-'0'-1;
			findrow=seats.length-1-(seatName.charAt(2)-'A');
			}
		else {
			System.out.printf("[예약 실패]: 잘못된 좌석 이름입니다.\n");
			return -1;
			
		}
		
		
		if(Character.isDigit(seatName.charAt(0))==false) {
			System.out.printf("%s: 숫자가 아닌 잘못된 좌석 이름입니다. \n",seatName);
			System.out.printf("[예약 실패]: 잘못된 좌석 이름입니다.\n");
			return -1;
		}
		
		else if(!((0<=findrow&&findrow<seats.length)&&(0<=findcol&&findcol<seats[0].length))) {
			System.out.printf("%s: 좌석의 범위를 넘은 잘못된 좌석 이름입니다. \n",seatName);
			System.out.printf("[예약 실패]: 잘못된 좌석 이름입니다.\n");
			return -1;
		}
	
		else if(this.seats[findrow][findcol]==0) {
			this.seats[findrow][findcol]=1;
			System.out.printf("[예약 성공] %s\n",seatName);
			Seat++;
			
			
			
			return 0;
		}
		
		else if(this.seats[findrow][findcol]==1) {
			System.out.printf("[예약 실패] %s: 이미 예약된 좌석입니다.\n",seatName);
			return -1;
		}
		
		else {
			System.out.printf("[예약 실패]: 잘못된 좌석 이름입니다.\n");
			return -1;
			
		}
	}

	

	public int cancelSeat(String seatName) {
		if(seatName.length()==2) {
			  findcol=seatName.charAt(0)-'0'-1;
			  findrow=seats.length-1-(seatName.charAt(1)-'A');
			}
				
		else if(seatName.length()==3) {
				findcol=(seatName.charAt(0)-'0')*10+(seatName.charAt(1)-'0')-1;
				findrow=seats.length-1-(seatName.charAt(2)-'A');
			}
		
		else {
				System.out.printf("[예약 취소 실패]: 잘못된 좌석 이름입니다.\n");
				return -1;
				
			}
		
		
		if(Character.isDigit(seatName.charAt(0))==false) {
			System.out.printf("%s: 숫자가 아닌 잘못된 좌석 이름입니다. \n",seatName);
			System.out.printf("[예약 취소 실패]: 잘못된 좌석 이름입니다.\n");
			return -1;
		}
		
		else if(!((0<=findrow&&findrow<seats.length)&&(0<=findcol&&findcol<seats[0].length))) {
				System.out.printf("%s : 좌석의 범위를 넘은 잘못된 좌석 이름입니다. \n",seatName);
				System.out.printf("[예약 취소 실패]: 잘못된 좌석 이름입니다.\n");
				return -1;
			}
		
		else if(this.seats[findrow][findcol]==1) {
				this.seats[findrow][findcol]=2;
				System.out.printf("[예약 취소 성공] %s\n",seatName);
				Seat--;
				
				return 0;
			}
			
		else if(this.seats[findrow][findcol]==0) {
				System.out.printf("[예약 취소 실패] %s: 예약 되지 않은 좌석입니다.\n",seatName);
				return -1;
			}
		
		else {
				System.out.printf("[예약 취소 실패]: 잘못된 좌석 이름입니다.\n");
				return -1;
				
			}
	

	}



}

//2021114818
//김찬호
public class Person extends Thread{
	KtxSeat callback;
	String name;
	int num;
	String seat[][]= new String[4][10];
	
			
			
	
	public Person(KtxSeat obj,String name) {
		this.callback=obj;
		this.name=name;
	}
	
	public void run() {
		
		for(int i=0;i<20;i++) {
			
			makeNum();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void makeNum() {
		num=(int)(Math.random()*45+1);
	}
	


}

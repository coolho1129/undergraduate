import java.io.*;
public class FileReadKorean {

	public static void main(String[] args) {
		InputStreamReader in = null;
		FileInputStream fin = null;
		try {
			fin = new FileInputStream("/Users/changsu/temp/hangul1.txt");
			in = new InputStreamReader(fin, "MS949");	// 문자 스트림 클래스
			//in = new InputStreamReader(fin, "UTF8");	// 문자 스트림 클래스
			int c;
					
			System.out.println("Encoding charset: " + in.getEncoding());
			
			while((c=in.read())!= -1) {
				System.out.print((char)c);
			}
			in.close();
			fin.close();
		} catch (IOException e) {			
			e.printStackTrace();
		}
	}
}

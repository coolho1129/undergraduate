import java.io.*;

public class FileReaderEx01 {

	public static void main(String[] args) {
		
		
		try {
			FileReader fin = new FileReader("test.txt");
			
			int c;
			while ((c = fin.read()) != -1) {
				System.out.print((char)c);
			}
			fin.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		
	}

}

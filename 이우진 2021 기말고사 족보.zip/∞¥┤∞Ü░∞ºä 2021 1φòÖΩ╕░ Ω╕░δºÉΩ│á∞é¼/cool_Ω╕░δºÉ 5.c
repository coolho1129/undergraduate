#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> 
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <malloc.h>


typedef struct diary
{

	int month;
	int day;
	char consum[100];
	int money;



}diary;

void main()
{
	FILE* f;
	diary dia = { 0, };
	int dayily_money[12][31] = { 0 }, monthly_money[100] = { 0 }, m

	f = fopen("diary.txt", "r");
	
	if (f == NULL)
	{
		printf("Cannot find the file\n");
		exit(0);
	}

	while (fscanf(f, "%d.%d %s %d", &dia.month, &dia.day, dia.consum, &dia.money) != EOF)
	{
		daily_money[dia.month - 1][dia.day - 1] += dia.money;

	}

	printf("Daily\n");
	for (int i = 0; i < 12; i++)
	{
		for (int j = 0; j < 31; j++)
		{
			if (daily_money[i][j] != 0)
			{
				printf("%d.%d: %d\n", i + 1, j + 1, month_day[i][j]);
			}
		}
	}
	printf("\nMonthly\n");
	for (int i = 0; i < 12; i++)
	{
		for (int j = 0; j < 31; j++)
		{
			monthly_money[i] += daily_money[i][j];


		}
		if (monthly_money[i] != 0)
			printf("%d: %d\n", i + 1, monthly_money[i]);
	}



}